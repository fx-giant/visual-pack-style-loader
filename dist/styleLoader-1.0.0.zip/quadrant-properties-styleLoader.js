namespace("fx.quadrantProperties")["styleLoader"] = (function () {

    function viewModel(params) {
        var me = this;
        $.extend(true, me, {});
        return;
    }

    viewModel.prototype.dispose = function () { }

    return {
        viewModel: viewModel
    };
})();